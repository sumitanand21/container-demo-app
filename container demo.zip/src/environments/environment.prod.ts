export const environment = {
  production: true,
  apiEndPoint: 'https://container-config.herokuapp.com/api'
};
