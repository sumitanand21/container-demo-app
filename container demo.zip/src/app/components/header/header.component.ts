import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { KeycloakService } from 'keycloak-angular';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  networkSpeedStatus = false;
  user = 'User Name';
  @Output() emitOut = new EventEmitter<any>();
  constructor(private router: Router, private keycloakService: KeycloakService) { }

  ngOnInit(): void {
    if(this.keycloakService && this.keycloakService.hasOwnProperty('getUsername')){
      this.user = this.keycloakService.getUsername();
    }

  }

  toggleSideNav(){
    this.emitOut.emit(true);
  }

  logOut(){
    this.keycloakService.logout();
  }

  upsertConfiguration(){
    this.router.navigate(['/upsertapp']);
  }
}
