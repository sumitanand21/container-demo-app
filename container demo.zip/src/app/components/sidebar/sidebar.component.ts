
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { KeycloakService } from 'keycloak-angular';
export interface SideMenu {
  name: string;
  menuItems: Array<any>;
  img: any;
  routerLink: string;
}
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
  isActive = true;
  shouldRun = true;
  headerName;
  @ViewChild('sidenav')
  sidenav: MatSidenav;
  isSelected = false;
  reason = '';
  defaultLocale = 'en';
  defaultMenu = [
    {
      name: 'Container',
      img: 'assets/icons/icons8-medical-container-50.png',
      routerLink: '/container',
      menuItems: [
        {
          name: 'View',
          routerLink: '/container',
          isSelected: false,
        },
        {
          name: 'Add New App',
          routerLink: '/upsertapp',
          isSelected: false,
        },
        {
          name: 'Restore Apps',
          routerLink: '/restoreapp',
          isSelected: false,
        }
      ],
    },
    {
      name: 'Settings',
      img: 'assets/icons/icons8-settings-50.png',
      routerLink: '/settings',
      menuItems: [
        {
          name: 'View',
          routerLink: '/settings',
          isSelected: true,
        },
      ],
    },
    {
      name: 'About',
      img: 'assets/icons/icons8-info-50.png',
      routerLink: '/info',
      menuItems: [
        {
          name: 'info',
          routerLink: '/info',
          isSelected: false,
        }
      ],
    }
  ];
  panelOpenState = false;
  sideMenuData: SideMenu[];
  @Input()
  set sideBarApps(value) {
    this.intializeMenu(value);
  }
  constructor(private keycloakService: KeycloakService
  ) {}
  close(reason: string) {
    this.reason = reason;
    this.sidenav.close();
  }

  ngOnInit() {
  }

  logOut(){
    if(this.keycloakService && this.keycloakService.hasOwnProperty('logout')){
      this.keycloakService.logout();
    }

  }

  intializeMenu(appMenu) {
    this.sideMenuData = [...appMenu , ... this.defaultMenu];
  }
}
