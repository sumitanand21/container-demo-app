export class DataModel {
    name: any;
    url: any;
    isLandingPage: any = false;
    isNavbar: any = true;
    routePath: any;
    _id: any;
    isActive: any = false;
    label: any;
}