import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { BroadcastData } from './../models/BroadcastData';
@Injectable({
  providedIn: 'root'
})
export class GlobalEventDistributorService {

  dataSubject = new BehaviorSubject<any>(undefined);
  stores = [];
  broadcastStore = [];
  preloadingTopicStatus = [];
  constructor() {
      this.stores = [];
  }
   broadCostData(topic, data) {
     this.broadcastStore[topic] = data;
     this.dataSubject.next(this.broadcastStore);
   }
   setbroadCostData(topic, data) {
    this.broadcastStore[topic] = data;
  }
  getTopicStatus(topic): boolean {
    return this.preloadingTopicStatus[topic];
  }
  setTopicStatus(topic, status) {
    this.preloadingTopicStatus[topic] = status;
  }
   getBroadcastStore() {
     return this.broadcastStore;
   }
   getBroadcastStoreByTopic(topic) {
    return this.broadcastStore[topic] ? this.broadcastStore[topic] : [];
  }
   getDataFromContainer() {
     return this.dataSubject.asObservable();
   }
  registerStore(store) {
      this.stores.push(store);
  }

  dispatch(event) {
      console.log('event', event);
  }
}
