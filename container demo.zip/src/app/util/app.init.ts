import { KeycloakService } from 'keycloak-angular';

export function initializeKeycloak(keycloak: KeycloakService): () => Promise<boolean> {
    return () =>
        keycloak.init({
            config: {
                url: 'http://keycloak-keycloak.router.default.svc.cluster.local.167.254.204.64.nip.io/auth',
                realm: 'angular-web',
                clientId: 'angular-web-client',
            },
            initOptions: {
                onLoad: 'login-required',
                checkLoginIframe: true,
                checkLoginIframeInterval: 25
            },
            loadUserProfileAtStartUp: true
        });
}
