import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { RouteConfigService } from './services/route-config.service';
import { SingleSpaService } from './services/single-spa.service';
import { ContainerToasterService } from './services/container-toaster.service';
import { PreloadApiService } from './services/preload-api.service';
import { Subscription } from 'rxjs';
import { Title } from '@angular/platform-browser';
import { AfterContentChecked } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy, AfterContentChecked {
  @ViewChild('sidenav') public sideNav;
  isLoading = false;
  navbar;
  navStatus = false;
  configErr = false;
  landingPage;
  currntPage;
  mainApp;
  sideBarApps = [];
  sideBarAppsBinder = [];
  navbarBinder;
  navStatusBinder = false;
  id;
  subscriptions: Subscription[] = [];
  constructor(
    private router: Router,
    private titleService: Title,
    private routeConService: RouteConfigService,
    private singleSpaService: SingleSpaService,
    private containerToaster: ContainerToasterService,
    private preloadApiService: PreloadApiService) {

    const subRouter = router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.currntPage = event.url;
        if (!this.landingPage && !this.navbar && !this.mainApp) {
          this.anyAppLoaded();
        }
      }
    });
    const subRoute = this.routeConService.routeSubject.subscribe((res) => {
      if (res) {
        this.loadApp(res);
      } else {
        this.sideBarApps = [];
        this.navStatus = false;
        this.navbar = undefined;
      }
    });
    this.subscriptions.push(subRouter);
    this.subscriptions.push(subRoute);
  }
  ngOnInit() {
  }

  loadApp(mainApp): void {
    this.isLoading = true;
    const subMicroApps = this.singleSpaService.getMicroApps(mainApp._id).subscribe((res) => {
      if (res && res.length) {
        this.mainApp = mainApp;
        const appList = [];
        const innerApps = [];
        const innerNavs = [];
        res.forEach((app) => {
          if (app.isGroup) {
            if (app.isNavbar) {
              innerNavs[app.groupName] = app;
            } else {
              if (innerApps[app.groupName]) {
                innerApps[app.groupName].push(app);
              } else {
                innerApps[app.groupName] = [app];
              }
            }
          } else {
            if (app.isLandingPage) {
              this.landingPage = app.routePath;
            }
            if (app.isNavbar) {
              this.navbar = { app: app.routePath, mainApp, apiEndPoint: app.apiUrl, microApp: app };
              this.navStatus = true;
            } else {
              appList.push({
                img: 'assets/icons/icons8-puzzle-50.png',
                name: app.label,
                routerLink: app.routePath
              });
              this.router.config.unshift({
                path: app.routePath,
                children: [
                  {
                    path: '**',
                     loadChildren: () => import('./components/spa-verticle-host/spa-verticle-host.module')
                        .then(m =>  m.SpaVerticleHostModule),
                    data: { app: app.routePath, mainApp, apiEndPoint: app.apiUrl, microApp: app }
                  }]
              });
            }
          }
        });
        if (Object.keys(innerApps).length > 1 || true) {
          const appListFromInnerApps = [];
          Object.keys(innerApps).forEach((inrApps) => {
            innerApps[inrApps].forEach(element => {

              if (element.isLandingPage) {
                appList.push({
                  img: 'assets/icons/icons8-puzzle-50.png',
                  name: element.groupName,
                  routerLink: mainApp.namespace + '-' + element.groupName
                });
                this.router.config.unshift({
                  path: mainApp.namespace + '-' + element.groupName,
                  redirectTo: element.routePath,
                  pathMatch: 'full'
                });
              }
              if (innerNavs[inrApps]) {
                this.router.config.unshift({
                  path: element.routePath,
                  children: [
                    {
                      path: '**',
                      loadChildren: () => import('./components/spa-verticle-host/spa-verticle-host.module')
                        .then(m =>  m.SpaVerticleHostModule),
                      data: {
                        app: element.routePath, mainApp, apiEndPoint: element.apiUrl, microApp: element, innerNav: {
                          app: innerNavs[inrApps].routePath, mainApp,
                          apiEndPoint: innerNavs[inrApps].apiUrl, microApp: innerNavs[inrApps], innerApps: innerApps[inrApps]
                        }
                      }
                    }]
                });
              } else {
                this.router.config.unshift({
                  path: element.routePath,
                  children: [
                    {
                      path: '**',
                       loadChildren: () => import('./components/spa-verticle-host/spa-verticle-host.module')
                        .then(m =>  m.SpaVerticleHostModule),
                      data: { app: element.routePath, mainApp, apiEndPoint: element.apiUrl, microApp: element }
                    }]
                });
              }



            });
          });
        }

        this.sideBarApps = appList;
      } else {
        this.containerToaster.showWarning('Warning: Micro apps are not available');
      }
      this.isLoading = false;
      if (!this.currntPage || this.currntPage === '/' || this.currntPage === '/container') {
        if (this.landingPage) {
          this.router.navigateByUrl(this.landingPage);
          this.titleService.setTitle(mainApp.label);
          this.preloadApiService.loadApi(mainApp.preloadURLS);
        } else {
          this.containerToaster.showError('Error: Homepage/Landing page not available !');
          this.navbar = undefined;
          this.navStatus = false;
          this.sideBarApps = [];
          this.router.navigateByUrl('/container');
        }
      } else {
        this.router.navigateByUrl(this.currntPage);
      }
    }, err => {
      this.containerToaster.showError(err.message);
      this.isLoading = false;
    });
    this.subscriptions.push(subMicroApps);
  }
  anyAppLoaded(): void {
    if (this.currntPage && this.currntPage !== '/' && this.currntPage !== '/container'
      && this.currntPage !== '' && this.currntPage.includes('-')) {
      console.log(this.currntPage);
      const app = this.currntPage.split('-')[0];
      if (app && app.length > 1) {
        this.isLoading = true;
        const subMicroAppsByNamespace = this.singleSpaService.getMicroAppsByNamespace(app).subscribe((res) => {
          if (res && res.mainApp && res.microApps && res.microApps.length) {
            const innerApps = [];
            const innerNavs = [];
            this.mainApp = res.mainApp;
            const appList = [];
            res.microApps.forEach((ap) => {
              if (ap.isGroup) {
                if (ap.isNavbar) {
                  innerNavs[ap.groupName] = ap;
                } else {
                  if (innerApps[ap.groupName]) {
                    innerApps[ap.groupName].push(ap);
                  } else {
                    innerApps[ap.groupName] = [ap];
                  }
                }
              } else {
                if (ap.isLandingPage) {
                  this.landingPage = ap.routePath;
                }
                if (ap.isNavbar) {
                  this.navStatus = true;
                  this.navbar = { app: ap.routePath, mainApp: this.mainApp, apiEndPoint: ap.apiUrl, microApp: ap };
                } else {
                  appList.push({
                    img: 'assets/icons/icons8-puzzle-50.png',
                    name: ap.label,
                    routerLink: ap.routePath,
                  });
                  this.router.config.unshift({
                    path: ap.routePath,
                    children: [
                      {
                        path: '**',
                         loadChildren: () => import('./components/spa-verticle-host/spa-verticle-host.module')
                        .then(m =>  m.SpaVerticleHostModule),
                        data: {
                          app: ap.routePath,
                          mainApp: res.mainApp,
                          apiEndPoint: ap.apiUrl,
                          microApp: ap
                        }
                      }]
                  });
                }
              }
            });
            if (Object.keys(innerApps).length > 1 || true) {
              const appListFromInnerApps = [];
              Object.keys(innerApps).forEach((inrApps) => {
                innerApps[inrApps].forEach(element => {

                  if (element.isLandingPage) {
                    appList.push({
                      img: 'assets/icons/icons8-puzzle-50.png',
                      name: element.groupName,
                      routerLink: this.mainApp.namespace + '-' + element.groupName
                    });
                    this.router.config.unshift({
                      path: this.mainApp.namespace + '-' + element.groupName,
                      redirectTo: element.routePath,
                      pathMatch: 'full'
                    });
                  }
                  if (innerNavs[inrApps]) {
                    this.router.config.unshift({
                      path: element.routePath,
                      children: [
                        {
                          path: '**',
                          loadChildren: () => import('./components/spa-verticle-host/spa-verticle-host.module')
                            .then(m => m.SpaVerticleHostModule),
                          data: {
                            app: element.routePath, mainApp: this.mainApp, apiEndPoint: element.apiUrl, microApp: element,
                            innerNav: {
                              app: innerNavs[inrApps].routePath,
                              mainApp: this.mainApp,
                              apiEndPoint: innerNavs[inrApps].apiUrl,
                              microApp: innerNavs[inrApps],
                              innerApps: innerApps[inrApps]
                            }
                          }
                        }]
                    });
                  } else {
                    this.router.config.unshift({
                      path: element.routePath,
                      children: [
                        {
                          path: '**',
                           loadChildren: () => import('./components/spa-verticle-host/spa-verticle-host.module')
                        .then(m =>  m.SpaVerticleHostModule),
                          data: { app: element.routePath, mainApp: this.mainApp, apiEndPoint: element.apiUrl, microApp: element }
                        }]
                    });
                  }



                });
              });
            }
            this.sideBarApps = appList;
          } else {
            this.containerToaster.showWarning('Warning: Micro apps are not available');
          }
          this.isLoading = false;
          this.preloadApiService.loadApi(this.mainApp.preloadURLS);
          this.titleService.setTitle(this.mainApp.label);
          this.router.navigateByUrl(this.currntPage);
        }, err => {
          this.containerToaster.showError(err.message);
          this.isLoading = false;
        });
        this.subscriptions.push(subMicroAppsByNamespace);
      }
    }
  }

  toggleSideNav(evt) {
    if (evt) {
      this.sideNav.toggle();
    }
  }
  ngAfterContentChecked() {
    this.sideBarAppsBinder = this.sideBarApps;
    this.navStatusBinder = this.navStatus;
    this.navbarBinder = this.navbar;
  }
  ngOnDestroy() {
    if (this.subscriptions.length > 0) {
      this.subscriptions.forEach(sub => sub.unsubscribe());
    }
  }
}

