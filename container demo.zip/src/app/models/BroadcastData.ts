export interface BroadcastData {
    topic: string;
    data: any;
}