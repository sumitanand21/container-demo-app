import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConfigurationService {
  requestType = 'http://';
  secureRequestType = 'https://';
  ipHost = 'hostname';

  forecastPod = 30920;
  forecastOrderId = 1;
  forecastGrafana = '32300/d/CijHdYGMk/pm_forcast_1';
  forecastGrafanaUrl = '32300/d/CijHdYGMk/pm_forcast_1?orgId=1&orderId=1&var-PM_name=_vax_var-PM_name_vax_&kiosk=tv&refresh=5s';
  anomalyPod = 30807;
  schedulerPod = 30189;
  correlationPod = 30065;
  classificationPod = 31126;
  dataInsightsPod = 31007;
  forecastSocket = '31005/socket';
  anomalySocket = '31006/socket';
  profilerSocket = '31004/socket';
  dataInsightsSocket = '31005/socket';
  anomalyProfiler = 'anomaly_profiler*';
  classificationProfiler = 'basic_profiler*';
  socketScheduleExpTime = 3600;
  elPod = 32101;
  // tslint:disable-next-line:max-line-length
  elUrl = '/app/dashboards#/view/093906e0-6d22-11eb-933b-df15118cab21?_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:now-1M,to:now))&_a=(description:\'\',filters:!((\'$state\':(store:appState),meta:(alias:!n,disabled:!f,index:\'9ffb3930-6468-11eb-80b3-01f3d29be0ec\',key:kafka_consumer.modelName,negate:!f,params:(query:\'_vaxModelNamevax_\'),type:phrase),query:(match_phrase:(kafka_consumer.modelName:\'_vaxModelNamevax_\')))),fullScreenMode:!t,options:(hidePanelTitles:!f,useMargins:!t),query:(language:kuery,query:\'\'),timeRestore:!f,title:\'Loss Histogram\',viewMode:view)';
  userName = 'fujitsu';
  password = 'fujitsu';
  constructor() { }
}
