import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisplaypopupComponent } from '../dialogs/displaypopup/displaypopup.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';

@NgModule({
  declarations: [
    
  ],
  imports: [
    BrowserDynamicTestingModule,
  ],
  exports: [
    ],
  entryComponents: [DisplaypopupComponent],
  providers: [],

})
export class TestModule { }
