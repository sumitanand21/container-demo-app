import { Component } from '@angular/core';

@Component({
  selector: 'app-empty-route',
  template: '<h1>Vax</h1>',
})
export class EmptyRouteComponent {
}
