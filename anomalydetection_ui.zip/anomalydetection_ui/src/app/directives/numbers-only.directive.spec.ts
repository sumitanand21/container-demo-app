import { NumbersOnlyDirective } from './numbers-only.directive';

describe('NumbersOnlyDirective', () => {
  it('should create an instance', () => {
    const directive = NumbersOnlyDirective;
    expect(directive).toBeTruthy();
  });
});