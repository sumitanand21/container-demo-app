export class DataModel {
    name: any;
    value: any;
    uniquefeild: any;
}
