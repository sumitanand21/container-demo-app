import { DataModel } from './data-model.model';

describe('DataModel', () => {
  it('should create an instance', () => {
    expect(new DataModel()).toBeTruthy();
  });
});
