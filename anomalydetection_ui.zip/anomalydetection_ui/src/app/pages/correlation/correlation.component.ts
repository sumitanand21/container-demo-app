import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-correlation',
  templateUrl: './correlation.component.html',
  styleUrls: ['./correlation.component.scss']
})
export class CorrelationComponent implements OnInit {
  constructor() { }

  ngOnInit() {
  }
}
