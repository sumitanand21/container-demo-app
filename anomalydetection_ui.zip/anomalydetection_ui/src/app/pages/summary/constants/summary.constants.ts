export const SUMMARY_URLS = {
    GET_SUMMARY_DETAILS_API: '/datasource/api/getIFrameDetails/',
    GET_DATASET_LIST: '/datasource/api/getDataSet'
};
